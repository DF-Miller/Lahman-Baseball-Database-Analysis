USE lahmansbaseballdb;


 -----------------------------------------------------------------------------------------------------------------
-- Player Analysis
------------------------------------------------------------------------------------------------------------------


 -----------------------------------------------------------------------------------------------------------------
-- Players who appeared for the most teams
------------------------------------------------------------------------------------------------------------------

WITH mt AS (
	SELECT
		  playerID
		, COUNT(DISTINCT teamID) AS ttl_teams
	FROM batting
	GROUP BY playerID
		UNION
	SELECT
		  playerID
		, COUNT(DISTINCT teamID) AS ttl_teams
	FROM pitching
	GROUP BY playerID)

SELECT
	  p.nameGiven AS player
	, m.ttl_teams
    , DENSE_RANK() OVER(ORDER BY ttl_teams DESC) AS ttl_team_rank
FROM mt m
LEFT JOIN people p
ON m.playerID = p.playerID
WHERE INSTR(p.namegiven, ' ') <> 0  ;


---------------------------------------------------------------------------------------------------------------------
-- What Percentage of Players Play Less Than 10/100/162 Games
---------------------------------------------------------------------------------------------------------------------

WITH games AS (
    SELECT 
        playerID,
        SUM(G_all) AS ttl_games
    FROM appearances
    GROUP BY playerID
),
counts AS (
    SELECT
        COUNT(*) AS ttl_players,
        SUM(CASE WHEN ttl_games < 10 THEN 1 ELSE 0 END) AS ttl_ten,
        SUM(CASE WHEN ttl_games < 100 THEN 1 ELSE 0 END) AS ttl_hundred,
        SUM(CASE WHEN ttl_games < 162 THEN 1 ELSE 0 END) AS ttl_season
    FROM games
)
SELECT
	 ROUND((ttl_ten / ttl_players) * 100 , 2) AS Pct_less_than_10games
   , ROUND((ttl_hundred / ttl_players) * 100, 2) AS Pct_less_than_100games
   , ROUND((ttl_season / ttl_players) * 100, 2) AS Pct_less_than_season
FROM counts;

---------------------------------------------------------------------------------------------------------------------
-- Average amount of appearances
---------------------------------------------------------------------------------------------------------------------

SELECT 
	ROUND(AVG(G_all),2) as Average_Appearances
FROM appearances;


---------------------------------------------------------------------------------------------------------------------
-- Average Career Length by Decade (by debut year)
---------------------------------------------------------------------------------------------------------------------

SELECT 
	  FLOOR(YEAR(debut) / 10) * 10 AS decade
    ,  ROUND(AVG(DATEDIFF(finalGame, debut) / 365.25),2) AS career_avg_years
FROM people
GROUP BY decade
order by decade desc;

 -----------------------------------------------------------------------------------------------------------------
-- Average Age, Height, and Weight of Debut by year
------------------------------------------------------------------------------------------------------------------

SELECT 
		  YEAR(debut) as Year
		, ROUND( AVG ( 
		  YEAR(debut) - YEAR(birth_date) - (DATE_FORMAT(debut, '%m%d') < DATE_FORMAT(birth_date, '%m%d'))
		  ), 2) AS avg_debut_age
		, ROUND(AVG(weight)) AS avg_weight
        , ROUND(AVG(height)/12, 2) AS avg_height
		FROM people
        WHERE YEAR(debut) IS NOT NULL
		GROUP BY Year(debut)
		ORDER BY Year(debut) ASC ;


------------------------------------------------------------------------------------------------------------------
-- Players with the same Birthday
------------------------------------------------------------------------------------------------------------------

WITH bday AS (
    SELECT 
          birth_date 
        , nameGiven
    FROM people
)
SELECT 
    birth_date,
    GROUP_CONCAT(nameGiven SEPARATOR ', ') AS Name_Group
FROM bday
WHERE birth_date IS NOT NULL
GROUP BY birth_date
HAVING COUNT(nameGiven) > 2
ORDER BY birth_date;

------------------------------------------------------------------------------------------------------------------
-- First and Last Team (1985 and on)
------------------------------------------------------------------------------------------------------------------
With dates AS (
SELECT 
	  playerID
	, nameGiven
    , birthYear
    , birthMonth
    , birthDay
    , debut
    , finalGame
    , STR_TO_DATE(
            CONCAT(birthYear, '-', LPAD(birthMonth, 2, '0'), '-', LPAD(birthDay, 2, '0')),
            '%Y-%m-%d'
          ) AS Birthdate
FROM people),
careers AS
			(SELECT
			  playerID
			, nameGiven
			, birthYear
			, birthMonth
			, birthDay
			, debut
			, finalGame
			, Birthdate
			, ROUND (datediff(debut, Birthdate)/365, 2) AS debut_age
			, ROUND (datediff(finalGame, Birthdate)/365, 2) AS finalGame_age
			, ROUND (datediff(finalGame, debut)/365, 2) AS career_length 
			From dates) ,
 first_team AS
			( Select 
				  c.playerID
				, c.namegiven
				, c.debut
				, c.finalGame
				, c.Birthdate
				, c.debut_age
				, c.finalgame_age
				, c.career_length
				, s.teamID AS first_team
				from careers c
				INNER JOIN salaries s
				ON c.playerID = s.playerID AND YEAR(c.debut) = s.yearID
                ),
Last_team AS
		( Select
                  c.playerID
				, c.namegiven
				, c.debut
				, c.finalGame
				, c.Birthdate
				, c.debut_age
				, c.finalgame_age
				, c.career_length
				, c.first_team
                , s.teamID AS last_team
			FROM First_team c
            INNER JOIN salaries s
            ON c.playerID = s.playerID AND YEAR(c.finalgame) = s.yearID
            )
SELECT 
		 namegiven
		, YEAR(debut) AS debut_year
        , first_team
        , YEAR(finalgame) AS last_year
        , last_team
        FROM Last_team;

------------------------------------------------------------------------------------------------------------------
-- Debut Age, Final Game Age, and Career Length
------------------------------------------------------------------------------------------------------------------

With dates AS (
SELECT 
	  playerID
	, nameGiven
    , birthYear
    , birthMonth
    , birthDay
    , debut
    , finalGame
    , STR_TO_DATE(
            CONCAT(birthYear, '-', LPAD(birthMonth, 2, '0'), '-', LPAD(birthDay, 2, '0')),
            '%Y-%m-%d'
          ) AS Birthdate
FROM people)

SELECT *
	FROM
			(SELECT
			 nameGiven
			, timestampdiff (year, birthdate, debut) AS debut_age
			, timestampdiff (year, Birthdate, finalGame) AS finalGame_age
			, timestampdiff(year, debut, finalGame) AS career_length
			From dates)
            c
WHERE INSTR(namegiven, ' ') <> 0  
ORDER BY c.career_length DESC;


------------------------------------------------------------------------------------------------------------------
-- Started and Ended on Same team and played for 1 decade
------------------------------------------------------------------------------------------------------------------

With dates AS (
SELECT 
	  playerID
	, nameGiven
    , birthYear
    , birthMonth
    , birthDay
    , debut
    , finalGame
    , STR_TO_DATE(
            CONCAT(birthYear, '-', LPAD(birthMonth, 2, '0'), '-', LPAD(birthDay, 2, '0')),
            '%Y-%m-%d'
          ) AS Birthdate
FROM people),
careers AS
			(SELECT
			  playerID
			, nameGiven
			, birthYear
			, birthMonth
			, birthDay
			, debut
			, finalGame
			, Birthdate
			, ROUND (datediff(debut, Birthdate)/365, 2) AS debut_age
			, ROUND (datediff(finalGame, Birthdate)/365, 2) AS finalGame_age
			, ROUND (datediff(finalGame, debut)/365, 2) AS career_length 
			From dates) ,
 first_team AS
			( Select 
				  c.playerID
				, c.namegiven
				, c.debut
				, c.finalGame
				, c.Birthdate
				, c.debut_age
				, c.finalgame_age
				, c.career_length
				, s.teamID AS first_team
				from careers c
				INNER JOIN salaries s
				ON c.playerID = s.playerID AND YEAR(c.debut) = s.yearID
                ),
Last_team AS
		( Select
                  c.playerID
				, c.namegiven
				, c.debut
				, c.finalGame
				, c.Birthdate
				, c.debut_age
				, c.finalgame_age
				, c.career_length
				, c.first_team
                , s.teamID AS last_team
			FROM First_team c
            INNER JOIN salaries s
            ON c.playerID = s.playerID AND YEAR(c.finalgame) = s.yearID
            )
SELECT 
	nameGiven
    , first_team AS team
    , debut
    , finalgame
FROM Last_team
WHERE first_team = last_team AND
career_length >= 10;