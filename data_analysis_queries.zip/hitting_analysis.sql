USE lahmansbaseballdb;
----------------------------------------------------------------------------------------------------------------------
-- Hitting Analysis
----------------------------------------------------------------------------------------------------------------------
-- Hitting Statistics view
CREATE VIEW hitting_stats AS
SELECT
	  b.playerID
    , b.yearID
    , p.nameGiven AS Player
    , t.name AS Team
    , b.G
    , b.AB
    , b.H
    , b.HR
    , b.RBI
    , b.SB
    , b.HBP
    , b.BB
    , b.IBB
    , b.SF
    , b.SO
    , b.H / b.AB AS Batting_Average
    , (b.H + b.BB + b.HBP + b.IBB) / (b.AB + b.BB + b.IBB + b.HBP + b.SF) AS On_Base_Percentage
FROM batting b
	LEFT JOIN people p
    ON b.playerID = p.playerID
LEFT JOIN teams t
	ON b.teamID = t.teamID AND b.yearID = t.yearID ;


----------------------------------------------------------------------------------------------------------------------
-- Top Hitters for each team
-- Most Homeruns, Most RBIs, Best Batting Average, Best On Base Percentage 
----------------------------------------------------------------------------------------------------------------------

 ----------------------------------------------------------------------------------------------------------------------
 -- Best Home Run Hitter For Each Team
 ----------------------------------------------------------------------------------------------------------------------
WITH HR_hitters AS (    
		SELECT 
          playerID
		, Player
		, Team
		, SUM(HR) AS Total_HRs
		, SUM(HR) / SUM(G) AS HR_per_game
        , SUM(RBI) AS Total_RBIs
	FROM hitting_stats
  
	GROUP BY
		  playerID
		, Player
		, Team
          HAVING SUM(AB) >= 1500
)
    
SELECT * FROM (
SELECT *,
	DENSE_RANK() OVER(PARTITION BY Team ORDER BY Total_HRs DESC) AS Team_HR_Rank
FROM HR_hitters
) wnd
WHERE Team_HR_Rank <= 10 AND Total_HRs >= 25
ORDER BY Team;

----------------------------------------------------------------------------------------------------------------------
-- Best Overall Hitter Per Team
----------------------------------------------------------------------------------------------------------------------
WITH top_hitters AS (
	  SELECT
		  playerID
		, Player
		, Team
		, SUM(AB) AS ttl_AB
		, SUM(H) Ttl_hits
		, ROUND(SUM(H) / SUM(AB) * 1000) AS Career_BA
		, ROUND((COALESCE(SUM(H), 0) + COALESCE(SUM(BB), 0) + COALESCE(SUM(HBP), 0) + COALESCE(SUM(IBB), 0)) /
          NULLIF(COALESCE(SUM(AB), 0) + COALESCE(SUM(BB), 0) + COALESCE(SUM(HBP), 0) + COALESCE(SUM(IBB), 0) + COALESCE(SUM(SF), 0), 0) * 1000) AS Career_OBP
	FROM hitting_stats
	GROUP BY
          playerID
		,  Player
		, Team
	HAVING ttl_AB >= 1500 -- MLB record books require 1500 ABs to appear on career batting record books
)
SELECT * FROM
	(SELECT
          playerID
		, Player
        , Team
        , Career_BA
        , Career_OBP
        , DENSE_RANK() OVER(PARTITION BY Team ORDER BY Career_BA DESC) AS Batting_Avg_Rank
	 FROM top_hitters
     ) ba
WHERE Batting_Avg_Rank <= 10
ORDER BY 
	Team
    , Batting_Avg_Rank;

 ----------------------------------------------------------------------------------------------------------------------
 -- Top Batting Averages, OBPs, and Home Runs All Time
-----------------------------------------------------------------------------------------------------------------------

WITH top_hitters AS (
	  SELECT
          playerID
		, Player
		, SUM(AB) AS ttl_AB
		, SUM(H) Ttl_hits
        , SUM(HR) AS Total_HRs
		, ROUND(SUM(H) / SUM(AB) * 1000) AS Career_BA
		, ROUND((COALESCE(SUM(H), 0) + COALESCE(SUM(BB), 0) + COALESCE(SUM(HBP), 0) + COALESCE(SUM(IBB), 0)) /
          NULLIF(COALESCE(SUM(AB), 0) + COALESCE(SUM(BB), 0) + COALESCE(SUM(HBP), 0) + COALESCE(SUM(IBB), 0) + COALESCE(SUM(SF), 0), 0) * 1000) AS Career_OBP
	FROM hitting_stats
	GROUP BY
		  PlayerID
		, Player 
	HAVING
    SUM(AB) >= 1500  -- AND SUM(H) >= 250
    )
SELECT 
	  PlayerID
	, Player
    , Career_BA
    , Career_OBP
	, Total_HRs
    , DENSE_RANK() OVER( ORDER BY Career_BA DESC ) Batting_Average_Rank
    , DENSE_RANK() OVER( ORDER BY Career_OBP DESC ) OBP_Rank
    , DENSE_RANK() OVER( ORDER BY Total_HRs DESC ) HR_Rank
FROM top_hitters;


 ---------------------------------------------------------------------------------------------------------------------
-- Average Batting Average, Home Runs, Hits, Strikeouts, and Stolen Bases Per Season 
----------------------------------------------------------------------------------------------------------------------

SELECT
	  yearID AS year
	, ROUND(SUM(H) / SUM(AB) * 1000) AS AVG_BA
    , AVG(HR) AS AVG_HR
    , AVG(H) AS AVG_H
    , AVG(SO) AS AVG_SO
    , AVG(SB) AS ANG_SB
FROM hitting_stats 
GROUP BY yearID;

WITH all_players AS (
    SELECT
          yearID,
          SUM(H) / SUM(AB) * 1000 AS avg_ba_all,
          AVG(HR) AS avg_hr_all,
          AVG(H)  AS avg_h_all,
          AVG(SO) AS avg_so_all,
          AVG(SB) AS avg_sb_all
    FROM hitting_stats
    GROUP BY yearID),
qualifiers AS (
    SELECT
          yearID,
          SUM(H) / SUM(AB) * 1000 AS avg_ba_502,
          AVG(HR) AS avg_hr_502,
          AVG(H)  AS avg_h_502,
          AVG(SO) AS avg_so_502,
          AVG(SB) AS avg_sb_502
    FROM hitting_stats
    WHERE AB >= 502 -- In the MLB a player must have 3.1 AB's per game to qualify for awards (3.1 x 162 = ~502)
    GROUP BY yearID)
SELECT
      a.yearID
     , ROUND(a.avg_ba_all)   AS avg_ba_all
     , ROUND(q.avg_ba_502)   AS avg_ba_qualifiers
     , ROUND((ROUND(a.avg_ba_all) - ROUND(q.avg_ba_502)) / ROUND(a.avg_ba_all),3)  AS ba_502_v_league
     , a.avg_hr_all
     , q.avg_hr_502
     , ROUND((a.avg_hr_all - q.avg_hr_502) / a.avg_hr_all , 3) AS hr_502_v_league
     , a.avg_h_all
     , q.avg_h_502
     , ROUND((a.avg_h_all - q.avg_h_502) / a.avg_h_all , 3) AS hits_502_v_league
     , a.avg_so_all
     , q.avg_so_502
     , ROUND((a.avg_so_all - q.avg_so_502) / a.avg_so_all , 3) AS so_502_v_league
     , a.avg_sb_all
     , q.avg_sb_502
     , ROUND((a.avg_sb_all - q.avg_sb_502) / a.avg_sb_all , 3) AS sb_502_v_league
FROM all_players a
LEFT JOIN qualifiers q 
ON a.yearID = q.yearID
ORDER BY a.yearID DESC;

---------------------------------------------------------------------------------------------------------------------
-- % of Players Hitting of 300 or higher each year
---------------------------------------------------------------------------------------------------------------------

WITH cnt AS (
		SELECT
			  yearID
			, COUNT( DISTINCT playerID) AS ttl_300 -- Distinct used as extra check for possible errors in data 
		FROM hitting_stats
		WHERE Batting_Average >= 0.300
		GROUP BY yearID),
ttl AS (
		SELECT
			  yearID
			, COUNT(DISTINCT playerID) as ttl_players
		FROM hitting_stats
		GROUP BY yearID),
prcnt AS (
SELECT 
	  c.yearID
	, t.ttl_players
    , c.ttl_300
    , ROUND(c.ttl_300 / t.ttl_players * 100 , 2) AS prcnt_300_hitters
FROM cnt c
	LEFT JOIN ttl t
    ON c.YearID = t.yearID)

SELECT 
	  *
    , ROUND( 
			(( prcnt_300_hitters - LAG(prcnt_300_hitters) OVER(ORDER BY yearID ASC) ) 
			/ 
			LAG(prcnt_300_hitters) OVER(ORDER BY yearID ASC)) * 100
																	, 2 ) AS YoY_Change
	, ROUND(
			(( prcnt_300_hitters - LAG(prcnt_300_hitters) OVER(ORDER BY yearID ASC) ) 
			/ 
			LAG(prcnt_300_hitters, 5) OVER(ORDER BY yearID ASC)) * 100
																	,	2) AS 5Y_Change
from prcnt;

------------------------------------------------------------------------------------------------------------------
-- Best Three Years of Hitting
------------------------------------------------------------------------------------------------------------------
WITH rlg AS (
	SELECT
		  yearID
		, playerID
		, Batting_average
		, AVG(Batting_average) OVER (PARTITION BY playerID ORDER BY yearID ASC ROWS BETWEEN 2 PRECEDING AND CURRENT ROW) AS three_yr_avg
        , COUNT(*) OVER (PARTITION BY playerID ORDER BY yearID ASC ROWS BETWEEN 2 PRECEDING AND CURRENT ROW) AS window_size
	FROM hitting_stats
	WHERE AB >= 502)
SELECT
	  playerID
    , ROUND(three_yr_avg, 3) AS best_three_year_avg
FROM rlg
WHERE window_size = 3
ORDER BY three_yr_avg DESC
LIMIT 1;


---------------------------------------------------------------------------------------------------------------------
-- Players who have never hit below league average
---------------------------------------------------------------------------------------------------------------------

SELECT
      h.yearID,
      h.playerID,
      h.player,
      h.Batting_Average,
      la.league_BA
FROM hitting_stats h
INNER JOIN (
      SELECT
            yearID,
            ROUND(SUM(H) / SUM(AB), 3) AS league_BA
      FROM hitting_stats
      GROUP BY yearID
) la
      ON h.yearID = la.yearID
WHERE h.batting_average >= la.league_BA;


---------------------------------------------------------------------------------------------------------------------
-- League Wide Strike Out Rate Over Time
---------------------------------------------------------------------------------------------------------------------

WITH rate AS (
SELECT
	yearID
    , SUM(AB) AS total_ABs
    , SUM(SO) AS total_SOs
    , ROUND ( SUM(SO) / SUM(AB) * 100 , 2) AS SO_rate
FROM hitting_stats
GROUP BY yearID)

SELECT
	  yearID
    , SO_rate
		, (SO_rate - LAG(SO_rate) OVER (ORDER BY YearID ASC))
		/
		LAG(SO_rate) OVER (ORDER BY YearID ASC) AS SO_Rate_YoY_Chng
        
	, NTILE(5) OVER ( ORDER BY SO_rate ASC) AS SO_Rate_quintile
FROM rate
ORDER BY yearID;