USE lahmansbaseballdb;

------------------------------------------------------------------------------------------------------------------
-- Salary Analysis
------------------------------------------------------------------------------------------------------------------
    
------------------------------------------------------------------------------------------------------------------
-- Cumulative Salary Spend and 3 year Team Salary Rolling Average
------------------------------------------------------------------------------------------------------------------

WITH ttl AS (
SELECT 
	  yearID
    , teamID
    , SUM(salary) AS ttl_team_salary
FROM salaries
GROUP BY yearID, teamID
ORDER BY teamID, yearID)

SELECT
	  *
    , SUM(ttl_team_salary) OVER(PARTITION BY teamID ORDER BY yearID ASC) AS cumulative_spend
    , ROUND(AVG(ttl_team_salary) OVER(PARTITION BY teamID ORDER BY yearID ASC ROWS BETWEEN 2 PRECEDING and CURRENT ROW)) as avg_salary_last_three_yrs
FROM ttl;

------------------------------------------------------------------------------------------------------------------
--  First Year Each Team's Cumulative Spending surpassed 1 Billion
------------------------------------------------------------------------------------------------------------------
WITH ys AS (
	SELECT 
		yearID AS Yr
		, teamID AS Team
		, SUM(salary) AS Team_Year_Spend
	FROM salaries
GROUP BY 
		  yearID
		, teamID
	), 
    
Spend AS (
SELECT 
	Yr
    , Team
    , SUM(Team_Year_Spend) OVER ( PARTITION BY Team ORDER BY Yr ASC) AS Cumulative_Spend
FROM ys
ORDER BY 
	Team
	, yr ),
    
rnk AS (
	SELECT 
		yr
		, team
		, Cumulative_Spend
		, ROW_NUMBER() OVER(PARTITION BY Team ORDER BY yr ASC) AS Spend_Rank
	FROM Spend
    WHERE Cumulative_Spend >= 1000000000 )

SELECT 
	yr
    , team
    , Cumulative_Spend
FROM rnk
WHERE Spend_Rank = 1
ORDER BY Yr;

------------------------------------------------------------------------------------------------------------------
-- Top 20% of Teams in Average Annual Spending
------------------------------------------------------------------------------------------------------------------

 WITH ts AS (
	SELECT
			teamID,
			yearID, 
			SUM(salary) AS total_spend
	FROM salaries
	GROUP BY
			teamID,
			yearID),
av AS (
	SELECT
		teamID,
        ROUND(AVG(total_spend)) as Average_Spend
	FROM ts
    GROUP BY 
		teamID),
percentile AS (
	SELECT
		teamID,
        Average_Spend,
        NTILE(5) OVER ( ORDER BY Average_Spend) AS percentile
	FROM av)
SELECT * FROM percentile
 WHERE percentile = 5;